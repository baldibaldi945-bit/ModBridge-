# رفع ModBridge إلى GitHub وبناء APK

هذا المشروع جاهز للرفع كمصدر Android. اتبع الخطوات التالية من واجهة GitHub:

1. افتح GitHub ثم اختر **New repository**.
2. اسم مقترح للمستودع: `ModBridge`.
3. الوصف المقترح: `Offline FNF mod conversion to Psych Engine by AxelzeroX23`.
4. اختر **Public** أو **Private** حسب رغبتك. لا تفعّل إنشاء README أو `.gitignore` أو License جديد؛ فهذه الملفات موجودة داخل المشروع.
5. أنشئ المستودع الفارغ، ثم اختر **Add file → Upload files**.
6. فك ضغط `ModBridge-AxelzeroX23-GitHub-Ready.zip` على جهازك، ثم ارفع محتويات مجلد `ModBridge` نفسه، لا ملف ZIP المضغوط. يجب أن يظهر `settings.gradle.kts` و`build.gradle.kts` و`app/` و`core/` في جذر المستودع.
7. اكتب في رسالة الإيداع `Add ModBridge Android project` ثم اضغط **Commit changes** إلى فرع `main`.
8. افتح تبويب **Actions**. سيبدأ سير العمل **Build ModBridge APK** تلقائياً بعد الرفع. ويمكنك تشغيله يدوياً عبر **Run workflow**.
9. عندما ينتهي التشغيل بنجاح، افتح صفحة التشغيل وانزل إلى **Artifacts** ثم نزّل `ModBridge-debug-apk`. داخل الملف ستجد `app-debug.apk`.

## ملاحظات

- الناتج الحالي من سير العمل هو APK تجريبي **Debug** وليس APK إصدار نهائي موقّع للنشر.
- يجب أن تظهر علامة نجاح خضراء في Actions. إذا فشل البناء، افتح خطوة البناء وانسخ سجل الخطأ؛ اسم المهمة **Run core tests and build debug APK**.
- لا ترفع مفاتيح توقيع APK أو كلمات المرور إلى المستودع.
