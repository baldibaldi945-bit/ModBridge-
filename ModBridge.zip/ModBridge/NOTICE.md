# Creator and attribution notice

ModBridge is published under the creator identity **AxelzeroX23**.

Copyright © 2026 AxelzeroX23. All rights reserved for the original ModBridge application code and original artwork/audio supplied by the creator, except where a separate third-party licence applies.

Do not remove or misrepresent the creator attribution when redistributing this project. Third-party libraries and Android/Compose components remain subject to their own licences. This notice documents attribution; it does not technically prevent someone with source access from editing a fork.
