package com.modbridge.core

/**
 * Offline script migration assistant. This is a deterministic rule-based translator,
 * not a cloud LLM: it only emits Lua for patterns with known Psych Engine equivalents.
 * Unknown Haxe/HScript statements are intentionally excluded from the runtime output.
 */
internal object ScriptMigrationAI {
    data class Result(
        val lua: String,
        val recognized: Int,
        val skipped: Int,
        val recognizedFeatures: List<String>,
        val skippedExamples: List<String>
    )

    private data class Block(val callback: String, val body: String)

    fun translate(source: String): Result? {
        val extractedBlocks = extractBlocks(source)
        val hasFunctionDeclarations = Regex("(?:override\\s+)?function\\s+[A-Za-z_][A-Za-z0-9_]*\\s*\\(").containsMatchIn(source)
        val blocks = when {
            extractedBlocks.isNotEmpty() -> extractedBlocks
            hasFunctionDeclarations -> emptyList()
            else -> listOf(Block("onCreate", source))
        }
        val output = linkedMapOf<String, MutableList<String>>()
        val features = linkedSetOf<String>()
        val skipped = mutableListOf<String>()
        var recognized = 0

        for (block in blocks) {
            val statements = mutableListOf<String>()
            var unsupportedBlockDepth = 0
            var skipNextUnbracedStatement = false
            for (rawLine in block.body.lines()) {
                val line = rawLine.substringBefore("//").trim().trimEnd(';').trim()
                if (line.isBlank()) continue
                if (skipNextUnbracedStatement) { skipNextUnbracedStatement = false; continue }
                if (unsupportedBlockDepth > 0) {
                    unsupportedBlockDepth += line.count { it == '{' } - line.count { it == '}' }
                    continue
                }
                if (Regex("^(if|else|for|while|switch|try|catch|do)\\b").containsMatchIn(line)) {
                    val depth = line.count { it == '{' } - line.count { it == '}' }
                    unsupportedBlockDepth = depth.coerceAtLeast(0)
                    val hasInlineBody = line.lastIndexOf(')') in 0 until (line.length - 1) && line.substring(line.lastIndexOf(')') + 1).isNotBlank()
                    if (depth <= 0 && !hasInlineBody) skipNextUnbracedStatement = true
                    if (skipped.size < 12) skipped += "[conditional block skipped] ${line.take(120)}"
                    continue
                }
                if (line.startsWith("import ") || line.startsWith("package ") ||
                    line.startsWith("using ") || line.startsWith("var ") || line.startsWith("final ") ||
                    line.startsWith("public ") || line.startsWith("private ") || line == "{" || line == "}") continue
                val translated = translateStatement(line)
                if (translated != null) {
                    statements += translated.first
                    features += translated.second
                    recognized++
                } else if (looksExecutable(line)) {
                    if (skipped.size < 12) skipped += line.take(140)
                }
            }
            if (statements.isNotEmpty()) output.getOrPut(block.callback) { mutableListOf() }.addAll(statements)
        }
        if (recognized == 0) return null
        val lua = buildString {
            appendLine("-- ModBridge Offline Script AI: generated only from recognized safe patterns")
            appendLine("-- Untranslated source statements are intentionally not executed.")
            for ((callback, lines) in output) {
                val parameters = when (callback) {
                    "onUpdate", "onUpdatePost" -> "elapsed"
                    "onEvent" -> "name, value1, value2"
                    "onTimerCompleted" -> "tag, loops, loopsLeft"
                    "onTweenCompleted" -> "tag"
                    "onCountdownTick" -> "counter"
                    else -> ""
                }
                appendLine("function $callback($parameters)")
                lines.distinct().forEach { appendLine("    $it") }
                appendLine("end")
                appendLine()
            }
        }
        return Result(lua, recognized, skipped.size, features.toList(), skipped)
    }

    private fun extractBlocks(source: String): List<Block> {
        val lines = source.lines()
        val result = mutableListOf<Block>()
        var i = 0
        while (i < lines.size) {
            val line = lines[i]
            val match = Regex("(?:override\\s+)?function\\s+([A-Za-z_][A-Za-z0-9_]*)\\s*\\([^)]*\\)\\s*\\{?").find(line)
            if (match == null) { i++; continue }
            val name = match.groupValues[1]
            val callback = when (name) {
                "create", "onCreate" -> "onCreate"
                "update", "onUpdate" -> "onUpdate"
                "onUpdatePost" -> "onUpdatePost"
                "stepHit", "onStepHit" -> "onStepHit"
                "beatHit", "onBeatHit" -> "onBeatHit"
                "songStart", "onSongStart" -> "onSongStart"
                "onCountdownStarted", "onCountdownTick", "onEndSong", "onEvent", "onCreatePost",
                "onTimerCompleted", "onTweenCompleted" -> name
                else -> null
            }
            val openAt = line.indexOf('{')
            if (openAt >= 0 && line.indexOf('}', openAt + 1) > openAt) {
                val inline = line.substring(openAt + 1, line.lastIndexOf('}')).trim()
                if (callback != null && inline.isNotBlank()) result += Block(callback, inline)
                i++
                continue
            }
            val body = StringBuilder()
            var depth = line.count { it == '{' } - line.count { it == '}' }
            if (depth <= 0) depth = 1
            i++
            while (i < lines.size && depth > 0) {
                val current = lines[i]
                body.appendLine(current)
                depth += current.count { it == '{' } - current.count { it == '}' }
                i++
            }
            if (callback != null) result += Block(callback, body.toString())
        }
        return result
    }

    private fun translateStatement(line: String): Pair<String, String>? {
        fun q(value: String) = value.replace("\\", "\\\\").replace("'", "\\'")
        val zoom = Regex("(?:FlxG\\.camera\\.zoom|defaultCamZoom)\\s*=\\s*([^;]+)").find(line)
        if (zoom != null) return "setProperty('camGame.zoom', ${zoom.groupValues[1].trim()})" to "camera zoom"

        val flash = Regex("FlxG\\.camera\\.flash\\(\\s*([^,]+)\\s*,\\s*([^,)]+)").find(line)
        if (flash != null) {
            val color = flash.groupValues[1].trim().replace("FlxColor.WHITE", "'FFFFFF'").replace("FlxColor.BLACK", "'000000'").replace("FlxColor.RED", "'FF0000'")
            return "cameraFlash('game', $color, ${flash.groupValues[2].trim()})" to "camera flash"
        }

        val shake = Regex("FlxG\\.camera\\.shake\\(\\s*([^,]+)\\s*,\\s*([^,)]+)").find(line)
        if (shake != null) return "cameraShake('game', ${shake.groupValues[1].trim()}, ${shake.groupValues[2].trim()})" to "camera shake"

        val fade = Regex("FlxG\\.camera\\.fade\\(\\s*([^,]+)\\s*,\\s*([^,)]+)").find(line)
        if (fade != null) {
            val color = fade.groupValues[1].trim().replace("FlxColor.WHITE", "'FFFFFF'").replace("FlxColor.BLACK", "'000000'")
            return "cameraFade('game', $color, ${fade.groupValues[2].trim()}, false)" to "camera fade"
        }

        val playSound = Regex("FlxG\\.sound\\.play\\(\\s*Paths\\.sound\\(\\s*['\"]([^'\"]+)['\"]\\s*\\)\\s*(?:,\\s*([0-9.]+))?").find(line)
        if (playSound != null) return "playSound('${q(playSound.groupValues[1])}', ${playSound.groupValues[2].ifBlank { "1" }})" to "sound playback"

        val anim = Regex("(boyfriend|dad|gf)\\.playAnim\\(\\s*['\"]([^'\"]+)['\"](?:\\s*,\\s*(true|false))?").find(line)
        if (anim != null) return "characterPlayAnim('${anim.groupValues[1]}', '${q(anim.groupValues[2])}', ${anim.groupValues[3].ifBlank { "true" }})" to "character animation"

        val follow = Regex("FlxG\\.camera\\.scroll\\.set\\(\\s*([^,]+)\\s*,\\s*([^)]+)").find(line)
        if (follow != null) return "triggerEvent('Camera Follow Pos', tostring(${follow.groupValues[1].trim()}), tostring(${follow.groupValues[2].trim()}))" to "camera follow"

        val zoomTween = Regex("FlxTween\\.tween\\(\\s*FlxG\\.camera\\s*,\\s*\\{\\s*zoom\\s*:\\s*([^}]+)}\\s*,\\s*([0-9.]+)").find(line)
        if (zoomTween != null) return "doTweenZoom('mb_cameraZoom', 'camGame', ${zoomTween.groupValues[1].trim()}, ${zoomTween.groupValues[2]}, 'linear')" to "camera zoom tween"

        val shader = Regex("(?:new\\s+)?CustomShader\\(\\s*['\"]([^'\"]+)['\"]\\s*\\)").find(line)
        if (shader != null) return "initLuaShader('${q(shader.groupValues[1])}')" to "shader initialization"

        val sprite = Regex("(?:makeLuaSprite|makeAnimatedLuaSprite)\\(\\s*['\"]([^'\"]+)['\"]\\s*,\\s*['\"]([^'\"]+)['\"]\\s*,\\s*(-?[0-9.]+)\\s*,\\s*(-?[0-9.]+)\\s*\\)").find(line)
        if (sprite != null) return "makeLuaSprite('${q(sprite.groupValues[1])}', '${q(sprite.groupValues[2])}', ${sprite.groupValues[3]}, ${sprite.groupValues[4]})" to "sprite creation"

        val charProperty = Regex("(boyfriend|dad|gf)\\.(x|y|alpha|angle)\\s*=\\s*([^;]+)").find(line)
        if (charProperty != null) return "setProperty('${charProperty.groupValues[1]}.${charProperty.groupValues[2]}', ${charProperty.groupValues[3].trim()})" to "character property"

        val directSet = Regex("setProperty\\(\\s*['\"]([^'\"]+)['\"]\\s*,\\s*(.+)\\)").find(line)
        if (directSet != null) return "setProperty('${q(directSet.groupValues[1])}', ${directSet.groupValues[2]})" to "Psych property"
        return null
    }

    private fun looksExecutable(line: String): Boolean =
        line.contains("(") || line.contains("=") || line.contains("new ") ||
            line.startsWith("if ") || line.startsWith("for ") || line.startsWith("while ")
}
