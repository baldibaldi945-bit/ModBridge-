package com.modbridge.app

import android.content.Intent
import android.media.MediaPlayer
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.FilterChip
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.awaitPointerEvent
import androidx.compose.ui.input.pointer.awaitPointerEventScope
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.documentfile.provider.DocumentFile
import com.modbridge.core.ArchiveConverter
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream
import kotlin.random.Random

private enum class AppPage { HOME, LIBRARY, SETTINGS, ABOUT }

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { ModBridgeScreen() }
    }

    @Composable
    private fun ModBridgeScreen() {
        val preferences = remember { getSharedPreferences("modbridge-preferences", MODE_PRIVATE) }
        var languageName by rememberSaveable {
            mutableStateOf(preferences.getString("language", AppLanguage.ALGERIAN_ARABIC.name) ?: AppLanguage.ALGERIAN_ARABIC.name)
        }
        val language = remember(languageName) {
            runCatching { AppLanguage.valueOf(languageName) }.getOrDefault(AppLanguage.ALGERIAN_ARABIC)
        }
        val strings = remember(language) { stringsFor(language) }
        var darkMode by rememberSaveable { mutableStateOf(preferences.getBoolean("dark_mode", false)) }
        var soundsEnabled by rememberSaveable { mutableStateOf(preferences.getBoolean("sounds", true)) }
        var pageName by rememberSaveable { mutableStateOf(AppPage.HOME.name) }
        val page = runCatching { AppPage.valueOf(pageName) }.getOrDefault(AppPage.HOME)

        var sourceUri by remember { mutableStateOf<Uri?>(null) }
        var targetUri by remember { mutableStateOf<Uri?>(null) }
        var sourceLabel by remember { mutableStateOf(strings.noArchive) }
        var targetLabel by remember { mutableStateOf(strings.noFolder) }
        var selectedEngine by rememberSaveable { mutableStateOf("Auto") }
        var status by remember { mutableStateOf(strings.ready) }
        var report by remember { mutableStateOf("") }
        var busy by remember { mutableStateOf(false) }
        var showSuccessDialog by remember { mutableStateOf(false) }
        var includeBackup by rememberSaveable { mutableStateOf(false) }
        var optimizeShaders by rememberSaveable { mutableStateOf(preferences.getBoolean("optimize_shaders", true)) }
        var loaderVariant by remember { mutableStateOf(0) }
        var libraryItems by remember { mutableStateOf(SavedArchiveStore(this).list()) }
        val store = remember { SavedArchiveStore(this) }
        val scope = rememberCoroutineScope()

        val sourcePicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            if (uri != null) {
                sourceUri = uri
                sourceLabel = runCatching {
                    contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { cursor ->
                        if (cursor.moveToFirst()) cursor.getString(0) else null
                    }
                }.getOrNull() ?: uri.lastPathSegment ?: "Mod.zip"
                status = strings.ready
                report = ""
            }
        }
        val targetPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
            if (uri != null) {
                targetUri = uri
                targetLabel = DocumentFile.fromTreeUri(this, uri)?.name ?: uri.lastPathSegment ?: "Output"
                runCatching {
                    contentResolver.takePersistableUriPermission(
                        uri,
                        Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                    )
                }
            }
        }

        fun playUiSound(resourceId: Int) {
            if (!soundsEnabled) return
            runCatching {
                val player = MediaPlayer.create(this, resourceId) ?: return
                player.setOnCompletionListener { it.release() }
                player.start()
            }
        }

        LaunchedEffect(language) {
            if (sourceUri == null) sourceLabel = strings.noArchive
            if (targetUri == null) targetLabel = strings.noFolder
            if (!busy && report.isBlank()) status = strings.ready
        }

        DisposableEffect(soundsEnabled) {
            val music = if (soundsEnabled) runCatching {
                MediaPlayer.create(this@MainActivity, R.raw.background_loop)?.apply {
                    isLooping = true
                    setVolume(0.45f, 0.45f)
                    start()
                }
            }.getOrNull() else null
            onDispose { runCatching { music?.stop() }; music?.release() }
        }

        LaunchedEffect(page) { libraryItems = store.list() }

        val palette = if (darkMode) darkColorScheme(
            primary = Color(0xFF9A7BFF), secondary = Color(0xFFFF4B9B), tertiary = Color(0xFF66C7D8),
            background = Color(0xFF050505), surface = Color(0xFF111111), surfaceVariant = Color(0xFF1D1D1D),
            onBackground = Color(0xFFF5F5F5), onSurface = Color(0xFFF5F5F5), onSurfaceVariant = Color(0xFFCECECE)
        ) else lightColorScheme(
            primary = Color(0xFF6840C8), secondary = Color(0xFFE91E78), tertiary = Color(0xFF168DA3),
            background = Color(0xFFFFFFFF), surface = Color(0xFFFFFFFF), surfaceVariant = Color(0xFFF3F0FA),
            onBackground = Color(0xFF15121A), onSurface = Color(0xFF15121A), onSurfaceVariant = Color(0xFF56515E)
        )

        var cursorPosition by remember { mutableStateOf(Offset.Unspecified) }
        var cursorVisible by remember { mutableStateOf(false) }
        LaunchedEffect(cursorPosition) {
            if (cursorPosition != Offset.Unspecified) {
                cursorVisible = true
                delay(480)
                cursorVisible = false
            }
        }

        androidx.compose.runtime.CompositionLocalProvider(
            LocalLayoutDirection provides if (language == AppLanguage.ENGLISH || language == AppLanguage.PORTUGUESE) LayoutDirection.Ltr else LayoutDirection.Rtl
        ) {
            MaterialTheme(colorScheme = palette) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(MaterialTheme.colorScheme.background)
                        .pointerInput(Unit) {
                            awaitPointerEventScope {
                                while (true) {
                                    val event = awaitPointerEvent(PointerEventPass.Initial)
                                    val change = event.changes.firstOrNull()
                                    if (change != null && change.pressed) cursorPosition = change.position
                                }
                            }
                        }
                ) {
                    Column(modifier = Modifier.fillMaxSize()) {
                        AppHeader(strings, onCreator = {
                            playUiSound(R.raw.button_click)
                            openExternal(CreatorBranding.YOUTUBE)
                        })
                        AnimatedContent(
                            targetState = page,
                            modifier = Modifier.weight(1f).fillMaxWidth(),
                            transitionSpec = {
                                (slideInHorizontally { it / 4 } + fadeIn()) togetherWith
                                    (slideOutHorizontally { -it / 6 } + fadeOut())
                            },
                            label = "page-slide"
                        ) { destination ->
                            when (destination) {
                                AppPage.HOME -> HomePage(
                                    strings = strings,
                                    sourceLabel = sourceLabel,
                                    targetLabel = targetLabel,
                                    selectedEngine = selectedEngine,
                                    onEngine = { selectedEngine = it; playUiSound(R.raw.button_click) },
                                    onPickArchive = { playUiSound(R.raw.button_click); sourcePicker.launch(arrayOf("*/*")) },
                                    onPickFolder = { playUiSound(R.raw.button_click); targetPicker.launch(null) },
                                    optimizeShaders = optimizeShaders,
                                    onOptimizeShaders = { optimizeShaders = it; preferences.edit().putBoolean("optimize_shaders", it).apply() },
                                    includeBackup = includeBackup,
                                    onIncludeBackup = { includeBackup = it },
                                    busy = busy,
                                    loaderVariant = loaderVariant,
                                    status = status,
                                    report = report,
                                    onConvert = {
                                        playUiSound(R.raw.button_click)
                                        val selectedSource = sourceUri
                                        val selectedTarget = targetUri
                                        if (selectedSource == null || selectedTarget == null) {
                                            status = strings.chooseFirst
                                            return@HomePage
                                        }
                                        busy = true
                                        val roll = Random.nextInt(100)
                                        loaderVariant = when (roll) { in 0..69 -> 0; in 70..89 -> 1; else -> 2 }
                                        status = strings.analysing
                                        report = ""
                                        val backupOption = includeBackup
                                        val shaderOption = optimizeShaders
                                        val originalName = sourceLabel
                                        val manualEngine = selectedEngine.takeIf { it != "Auto" }
                                        scope.launch {
                                            val operation = withContext(Dispatchers.IO) {
                                                runCatching {
                                                    val input = contentResolver.openInputStream(selectedSource)?.use { stream ->
                                                        val output = ByteArrayOutputStream()
                                                        val buffer = ByteArray(64 * 1024)
                                                        var totalBytes = 0L
                                                        while (true) {
                                                            val count = stream.read(buffer)
                                                            if (count < 0) break
                                                            totalBytes += count
                                                            require(totalBytes <= 256L * 1024L * 1024L) {
                                                                "حجم الأرشيف أكبر من حد القراءة الآمن (256MB)."
                                                            }
                                                            output.write(buffer, 0, count)
                                                        }
                                                        output.toByteArray()
                                                    } ?: error("تعذرت قراءة الأرشيف المختار.")

                                                    val converted = ArchiveConverter.convert(
                                                        input,
                                                        includeSourceBackup = backupOption,
                                                        optimizeShaders = shaderOption,
                                                        sourceName = originalName,
                                                        sourceOverride = manualEngine
                                                    )
                                                    val atlas = AndroidSpriteSheetBuilder.process(converted.bytes)
                                                    val finalArchive = atlas.archive
                                                    val safeSource = converted.source.replace(Regex("[^A-Za-z0-9_-]"), "-")
                                                    val fileName = "ModBridge-$safeSource-Psych.zip"
                                                    val tree = DocumentFile.fromTreeUri(this@MainActivity, selectedTarget)
                                                        ?: error("مجلد الإخراج غير صالح.")
                                                    tree.findFile(fileName)?.delete()
                                                    val resultFile = tree.createFile("application/zip", fileName)
                                                        ?: error("تعذر إنشاء ملف ZIP في مجلد الإخراج.")
                                                    contentResolver.openOutputStream(resultFile.uri)?.use { it.write(finalArchive) }
                                                        ?: error("تعذر حفظ ملف ZIP الناتج.")
                                                    val savedInLibrary = runCatching { store.save(finalArchive, converted.source) }.isSuccess
                                                    Triple(converted, atlas, finalArchive.size to savedInLibrary)
                                                }
                                            }
                                            operation.onSuccess { (converted, atlas, sizeAndSaved) ->
                                                val (outputSize, savedInLibrary) = sizeAndSaved
                                                status = if (savedInLibrary) "${strings.outputDone}\n${strings.saved} ✓" else strings.outputDone
                                                report = buildString {
                                                    appendLine("Source: ${converted.source}")
                                                    appendLine("Files scanned: ${converted.files}")
                                                    appendLine("Charts converted: ${converted.charts}")
                                                    appendLine("Recognized scripts translated: ${converted.scriptsTranslated}")
                                                    appendLine("Sprite atlases: ${atlas.atlases} • Frames: ${atlas.frames}")
                                                    appendLine("ZIP size: ${outputSize / 1024} KB")
                                                    appendLine("Unsupported source files excluded: ${converted.sourceFilesExcluded}")
                                                    if (!savedInLibrary) appendLine("Library copy could not be saved; the exported ZIP is still available.")
                                                    (converted.warnings + atlas.warnings).take(60).forEach { appendLine("• $it") }
                                                }
                                                libraryItems = store.list()
                                                showSuccessDialog = true
                                                playUiSound(R.raw.conversion_success)
                                            }.onFailure { error ->
                                                status = "${strings.unsupported}\n${error.message ?: "Unknown error"}"
                                                report = "لم يتم إنشاء ملف ناتج. تأكد من أن الأرشيف يحتوي بنية مصدر مدعومة وغير مشفرة بكلمة مرور."
                                            }
                                            busy = false
                                        }
                                    }
                                )
                                AppPage.LIBRARY -> LibraryPage(
                                    strings = strings,
                                    items = libraryItems,
                                    onExport = { item ->
                                        playUiSound(R.raw.button_click)
                                        val folder = targetUri
                                        if (folder == null) status = strings.chooseFirst
                                        else {
                                            val ok = runCatching { store.export(item, folder) }.getOrDefault(false)
                                            status = if (ok) strings.outputDone else "تعذر تصدير الملف."
                                        }
                                    },
                                    onDelete = { item ->
                                        playUiSound(R.raw.button_click)
                                        store.delete(item)
                                        libraryItems = store.list()
                                    }
                                )
                                AppPage.SETTINGS -> SettingsPage(
                                    strings = strings,
                                    language = language,
                                    darkMode = darkMode,
                                    soundsEnabled = soundsEnabled,
                                    onLanguage = {
                                        languageName = it.name
                                        preferences.edit().putString("language", it.name).apply()
                                        playUiSound(R.raw.button_click)
                                    },
                                    onDarkMode = {
                                        darkMode = it
                                        preferences.edit().putBoolean("dark_mode", it).apply()
                                        playUiSound(R.raw.button_click)
                                    },
                                    onSounds = {
                                        soundsEnabled = it
                                        preferences.edit().putBoolean("sounds", it).apply()
                                    }
                                )
                                AppPage.ABOUT -> AboutPage(strings, onYoutube = {
                                    playUiSound(R.raw.button_click)
                                    openExternal(CreatorBranding.YOUTUBE)
                                }, onInstagram = {
                                    playUiSound(R.raw.button_click)
                                    openExternal(CreatorBranding.INSTAGRAM)
                                })
                            }
                        }
                        BottomNavigation(strings, page, onNavigate = {
                            pageName = it.name
                            playUiSound(R.raw.button_click)
                        })
                    }
                    if (showSuccessDialog) {
                        AlertDialog(
                            onDismissRequest = { showSuccessDialog = false },
                            title = { Text("✓  ${strings.outputDone}", fontWeight = FontWeight.Bold) },
                            text = { Text(status) },
                            confirmButton = {
                                TextButton(onClick = {
                                    showSuccessDialog = false
                                    playUiSound(R.raw.button_click)
                                }) { Text(strings.ready) }
                            }
                        )
                    }
                    if (cursorVisible && cursorPosition != Offset.Unspecified) {
                        Image(
                            painter = painterResource(R.drawable.touch_cursor),
                            contentDescription = "Touch pointer",
                            modifier = Modifier
                                .offset { IntOffset(cursorPosition.x.toInt(), cursorPosition.y.toInt()) }
                                .size(30.dp)
                                .graphicsLayer(alpha = 0.88f),
                            contentScale = ContentScale.Fit
                        )
                    }
                }
            }
        }
    }

    private fun openExternal(url: String) {
        runCatching { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) }
    }

    @Composable
    private fun AppHeader(strings: UiStrings, onCreator: () -> Unit) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Image(
                painter = painterResource(R.drawable.app_icon),
                contentDescription = "${CreatorBranding.APP_NAME} by ${CreatorBranding.CREATOR}",
                modifier = Modifier.size(62.dp).clip(RoundedCornerShape(15.dp)),
                contentScale = ContentScale.Crop
            )
            Column(modifier = Modifier.weight(1f)) {
                Text(CreatorBranding.APP_NAME, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.ExtraBold)
                Text(strings.subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text("by ${CreatorBranding.CREATOR}", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
            }
            TextButton(onClick = onCreator) { Text("▶ YouTube") }
        }
        Divider(color = MaterialTheme.colorScheme.surfaceVariant)
    }

    @Composable
    private fun HomePage(
        strings: UiStrings,
        sourceLabel: String,
        targetLabel: String,
        selectedEngine: String,
        onEngine: (String) -> Unit,
        onPickArchive: () -> Unit,
        onPickFolder: () -> Unit,
        optimizeShaders: Boolean,
        onOptimizeShaders: (Boolean) -> Unit,
        includeBackup: Boolean,
        onIncludeBackup: (Boolean) -> Unit,
        busy: Boolean,
        loaderVariant: Int,
        status: String,
        report: String,
        onConvert: () -> Unit
    ) {
        Column(
            modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 10.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
                Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(strings.sourceEngine, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    Text(strings.sourceHint, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    listOf("Auto", "Codename Engine", "V-Slice", "Funky Maker Mobile").chunked(2).forEach { pair ->
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                            pair.forEach { engine ->
                                FilterChip(
                                    selected = selectedEngine == engine,
                                    onClick = { onEngine(engine) },
                                    label = { Text(when (engine) {
                                        "Auto" -> strings.autoDetect
                                        "Codename Engine" -> "Codename"
                                        "V-Slice" -> "V-Slice"
                                        else -> "FNMM"
                                    }, fontSize = 11.sp) },
                                    enabled = !busy,
                                    modifier = Modifier.weight(1f)
                                )
                            }
                        }
                    }
                }
            }

            Card {
                Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
                    Text(strings.chooseArchive, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    OutlinedButton(onClick = onPickArchive, enabled = !busy, modifier = Modifier.fillMaxWidth()) {
                        Text("📦  ${strings.chooseArchive}")
                    }
                    Text(sourceLabel, style = MaterialTheme.typography.bodySmall, maxLines = 2, overflow = TextOverflow.Ellipsis)
                    Divider(color = MaterialTheme.colorScheme.surfaceVariant)
                    Text(strings.outputFolder, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
                    OutlinedButton(onClick = onPickFolder, enabled = !busy, modifier = Modifier.fillMaxWidth()) {
                        Text("📁  ${strings.chooseFolder}")
                    }
                    Text(targetLabel, style = MaterialTheme.typography.bodySmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
            }

            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
                Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(strings.options, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    ToggleRow(strings.optimizeShaders, optimizeShaders, !busy, onOptimizeShaders)
                    ToggleRow(strings.sourceBackup, includeBackup, !busy, onIncludeBackup)
                }
            }

            Button(onClick = onConvert, enabled = !busy, modifier = Modifier.fillMaxWidth().height(52.dp)) {
                Text(if (busy) strings.converting else strings.start, fontWeight = FontWeight.Bold)
            }

            AnimatedVisibility(visible = busy) {
                Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
                    Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        AnimatedContent(targetState = loaderVariant, label = "loader-message") { variant ->
                            val (symbol, message) = when (variant) {
                                0 -> "✦" to strings.analysing
                                1 -> "◈" to strings.sourceHint
                                else -> "✧" to strings.converting
                            }
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(symbol, fontSize = 34.sp, color = MaterialTheme.colorScheme.primary)
                                Text(message, style = MaterialTheme.typography.bodyMedium)
                            }
                        }
                        LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
                    }
                }
            }
            Text(status, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold)
            AnimatedVisibility(visible = report.isNotBlank()) {
                Card {
                    Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text(strings.report, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        Text(report, style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
            Text(
                strings.aiNote,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(Modifier.height(8.dp))
        }
    }

    @Composable
    private fun LibraryPage(
        strings: UiStrings,
        items: List<SavedArchiveStore.Item>,
        onExport: (SavedArchiveStore.Item) -> Unit,
        onDelete: (SavedArchiveStore.Item) -> Unit
    ) {
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text(strings.library, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
            if (items.isEmpty()) Text(strings.noSaved, style = MaterialTheme.typography.bodyMedium)
            items.forEach { item ->
                Card {
                    Column(Modifier.fillMaxWidth().padding(12.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                        Text(item.source, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                        Text(item.fileName, style = MaterialTheme.typography.bodySmall, maxLines = 2, overflow = TextOverflow.Ellipsis)
                        Text("${item.sizeBytes / 1024} KB • ${java.text.DateFormat.getDateTimeInstance().format(java.util.Date(item.savedAt))}", style = MaterialTheme.typography.labelSmall)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(onClick = { onExport(item) }) { Text(strings.export) }
                            OutlinedButton(onClick = { onDelete(item) }) { Text(strings.delete) }
                        }
                    }
                }
            }
        }
    }

    @Composable
    private fun SettingsPage(
        strings: UiStrings,
        language: AppLanguage,
        darkMode: Boolean,
        soundsEnabled: Boolean,
        onLanguage: (AppLanguage) -> Unit,
        onDarkMode: (Boolean) -> Unit,
        onSounds: (Boolean) -> Unit
    ) {
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text(strings.settings, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
            Card {
                Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(strings.language, fontWeight = FontWeight.Bold)
                    AppLanguage.entries.forEach { option ->
                        FilterChip(
                            selected = option == language,
                            onClick = { onLanguage(option) },
                            label = { Text(when (option) {
                                AppLanguage.ALGERIAN_ARABIC -> "🇩🇿 العربية الجزائرية"
                                AppLanguage.ENGLISH -> "🇺🇸 English"
                                AppLanguage.PORTUGUESE -> "🇧🇷 Português"
                                AppLanguage.STANDARD_ARABIC -> "🇸🇦 العربية الفصحى"
                            }) },
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                }
            }
            Card {
                Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    ToggleRow(strings.darkMode, darkMode, true, onDarkMode)
                    ToggleRow(strings.sound, soundsEnabled, true, onSounds)
                }
            }
            Text("${CreatorBranding.APP_NAME} • ${CreatorBranding.CREATOR}", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }

    @Composable
    private fun AboutPage(strings: UiStrings, onYoutube: () -> Unit, onInstagram: () -> Unit) {
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Image(painterResource(R.drawable.app_icon), "${CreatorBranding.APP_NAME} icon", Modifier.size(68.dp).clip(RoundedCornerShape(14.dp)))
                Column {
                    Text(CreatorBranding.APP_NAME, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.ExtraBold)
                    Text("${strings.creator} ${CreatorBranding.CREATOR}", color = MaterialTheme.colorScheme.primary)
                }
            }
            Card { Text(strings.aboutText, Modifier.padding(14.dp), style = MaterialTheme.typography.bodyMedium) }
            Card { Text(strings.supports, Modifier.padding(14.dp), style = MaterialTheme.typography.bodyMedium) }
            Card { Text(strings.limitations, Modifier.padding(14.dp), style = MaterialTheme.typography.bodyMedium) }
            Text(strings.aiNote, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Text(strings.social, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Button(onClick = onYoutube) { Text("▶ YouTube") }
                OutlinedButton(onClick = onInstagram) { Text("◎ Instagram") }
            }
            Text(strings.copyright, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }

    @Composable
    private fun ToggleRow(label: String, checked: Boolean, enabled: Boolean, onChange: (Boolean) -> Unit) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(label, modifier = Modifier.weight(1f).padding(end = 8.dp), style = MaterialTheme.typography.bodyMedium)
            Switch(checked = checked, onCheckedChange = onChange, enabled = enabled)
        }
    }

    @Composable
    private fun BottomNavigation(strings: UiStrings, selected: AppPage, onNavigate: (AppPage) -> Unit) {
        Divider(color = MaterialTheme.colorScheme.surfaceVariant)
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 4.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically
        ) {
            val entries = listOf(
                AppPage.HOME to "⌂ ${strings.home}",
                AppPage.LIBRARY to "▤ ${strings.library}",
                AppPage.SETTINGS to "⚙ ${strings.settings}",
                AppPage.ABOUT to "ⓘ ${strings.about}"
            )
            entries.forEach { (page, label) ->
                TextButton(onClick = { onNavigate(page) }) {
                    Text(label, color = if (selected == page) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 11.sp, fontWeight = if (selected == page) FontWeight.Bold else FontWeight.Normal)
                }
            }
        }
    }
}
