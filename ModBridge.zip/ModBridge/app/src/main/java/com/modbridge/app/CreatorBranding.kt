package com.modbridge.app

/** Centralized creator identity and social destinations used by the app UI. */
internal object CreatorBranding {
    @JvmField val APP_NAME = "ModBridge"
    @JvmField val CREATOR = "AxelzeroX23"
    @JvmField val COPYRIGHT = "© 2026 AxelzeroX23. All rights reserved."
    @JvmField val YOUTUBE = "https://youtube.com/@axelzerox023?si=_bJ8WejYrM3Dnxx4"
    @JvmField val INSTAGRAM = "https://www.instagram.com/axelzerox023?obrf=MXA0aWgzcTY2dDk2Zg=="
}
