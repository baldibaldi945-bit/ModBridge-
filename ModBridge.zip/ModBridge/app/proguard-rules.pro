# Keep the creator attribution entry-point in release builds while allowing normal R8 shrinking.
-keep class com.modbridge.app.CreatorBranding { *; }
