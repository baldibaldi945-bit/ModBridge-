# ModBridge — AxelzeroX23

**Android project for converting supported Friday Night Funkin' mod archives to Psych Engine.**

ModBridge runs the conversion on the device after installation. It does not upload a user's mod archive to a server.

## Included source converters

- **V-Slice → Psych Engine**: converts supported charts and selected character/stage data, BPM changes, camera-focus events, and known chart events.
- **Codename Engine → Psych Engine**: converts supported charts, character XML, stage XML, and recognizable events.
- **Funky Maker Mobile (FNMM) → Psych Engine**: converts supported charts and character/stage descriptors.

ZIP and 7Z input archives are accepted. Nested ZIP/7Z archives are unpacked with depth and size limits. The app limits a selected archive to 256 MB, a single extracted entry to 128 MB, and total extracted content to 512 MB to reduce memory-exhaustion risk on phones. The app rejects unknown source layouts rather than returning a misleading "successful" conversion.

## App features

- Algerian Arabic, English, Portuguese, and Standard Arabic UI.
- Light/dark appearance, with the accent colours retained in both modes.
- Animated page transitions and a touch pointer image at the user's tap position.
- Optional looping background music, button sound effects, and a success sound/dialog.
- A private on-device library for the latest 30 successful converted ZIPs.
- YouTube and Instagram links for AxelzeroX23.
- User-provided app icon and audio/cursor assets are included in `app/src/main/res`.

## Conversion details

| Mod content | Current behaviour |
|---|---|
| Charts | Writes Psych chart JSON with supported notes, sustains, difficulties, BPM changes, and event mappings. |
| Characters | Converts supported Codename XML, V-Slice JSON, and FNMM descriptors to Psych character JSON. |
| Stages | Converts supported stage data to Psych stage JSON/Lua, including known props, positions, zoom, scale, scroll, and draw order. |
| Events | Maps recognized timing, BPM, camera, flash, animation, and related event fields. Unrecognized event types are reported. |
| FNMM sprite builder | Splits horizontal PNG strips according to `sprite.json`, packs frames into Sparrow PNG/XML atlases, and creates character JSON when the descriptor is valid. Original strips are removed only after a complete atlas is created. |
| Script migration | An offline rules-based helper translates a limited set of recognizable Haxe/HScript patterns into Psych Lua. |
| Shaders | Keeps shader files referenced by generated Lua and can remove unused ones. This is not a shader-language transpiler. |
| Audio/images/fonts | Copies compatible assets found in the source archive into Psych-style folders where their paths can be identified. |

### Important limitations

- The offline script helper is **not a large language model**. It uses deterministic local rules, does not execute source code, and does not invent equivalents for unknown Haxe/Flixel logic. Unsupported logic is skipped and reported.
- V-Slice custom note styles can declare separate `note`, `noteStrumline`, `holdNote`, `noteSplash`, and `holdNoteCover` assets. These are not automatically merged into a verified Psych `NOTE_assets`/splash atlas by this version. The converter records a warning when a non-default note style is detected. Do not assume custom V-Slice arrows, hold covers, or splashes have been converted; verify them in the target Psych Engine build.
- Custom engine states, menus, proprietary formats, unknown mechanics, and every shader/event combination cannot be guaranteed to convert.
- Password-protected archives are not supported by the current file picker/conversion flow.
- Always test the resulting ZIP in the exact Psych Engine version you use. Review `conversion-report.txt` and keep the source backup option enabled when experimenting with a valuable mod.

See **[GITHUB_GUIDE_AR.md](GITHUB_GUIDE_AR.md)** for the same upload and APK steps in Arabic.

## Build the APK with GitHub Actions

1. Extract this project ZIP on your computer.
2. Create a new repository on GitHub and upload the **contents** of the extracted `ModBridge` folder (the root should contain `settings.gradle.kts`, `build.gradle.kts`, `app/`, and `core/`).
3. Push the files to the `main` branch, or use the repository's **Actions** tab and run **Build ModBridge APK** manually.
4. Open the completed workflow run and download the artifact named **ModBridge-debug-apk**.
5. Inside the artifact is `app-debug.apk`.

The workflow runs the core tests and `assembleDebug`. This produces a **debug APK** for testing, not a release-signed Play Store APK.

## Build locally

Requirements: JDK 17, Android SDK 35, and Gradle 8.9.

```bash
gradle test assembleDebug
```

APK output path:

```text
app/build/outputs/apk/debug/app-debug.apk
```

## Creator attribution

The app UI, launcher label, `CreatorBranding` object, ProGuard keep rule, and `NOTICE.md` identify **AxelzeroX23** as the creator. Release minification makes casual edits less straightforward, but no attribution can be made cryptographically unchangeable in a public source repository: anyone who can fork/edit source can modify it. Keep the repository ownership and commit history under your account, and do not commit signing keys or passwords.
